enum HtmlType {
  termsAndCondition,
  aboutUs,
  privacyPolicy,
  cancellationPolicy,
  refundPolicy
}